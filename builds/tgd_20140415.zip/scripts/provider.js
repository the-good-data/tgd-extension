/*

  Copyright 2014 The Good Data Cooperative Ltd. / 
  Copyright 2010-2014 Disconnect, Inc.

  This program is free software, excluding the brand features and third-party 
  portions of the program identified in the “Exceptions” below: you can redis-
  tribute it and/or modify it under the terms of the GNU General Public License 
  as published by the Free Software Foundation, either version 3 of the License, 
  or (at your option) any later version.

  This program is distributed in the hope that it will be useful, but WITHOUT 
  ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or FITNESS 
  FOR A PARTICULAR PURPOSE. See the GNU General Public License for more details.

  You should have received a copy of the GNU General Public License along with 
  this program.  If not, see <http://www.gnu.org/licenses/>.

  Authors (one per line):
	
*/

var __cho__ = {"pid":3041};
var a="undefined"==typeof __cho__?{}:__cho__,d="undefined"==typeof a.data?{}:a.data;if(a.pid){var f=[],e=document,c=encodeURIComponent,g=e.location.protocol+"//cc.chango.com",b;for(b in a)"r"!=b&&("p"!=b&&"data"!=b)&&f.push(c(b)+"="+c(a[b]));for(b in d)f.push(c("__"+b)+"="+c(d[b]));f.push(c("__js__")+"="+c(!0));d=e.createElement("script");d.type="text/javascript";d.async=!0;d.src=g+"/c/"+(new Date).getTime()+"/o?p="+c(a.p?a.p:e.location.href)+"&r="+c(a.r?a.r:e.referrer)+"&"+f.join("&");a=e.getElementsByTagName("script")[0];a.parentNode.insertBefore(d,a)}
